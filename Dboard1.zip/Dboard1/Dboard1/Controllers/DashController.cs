﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DashBoard.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Web;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace DashBoard.Controllers
{
    [Route("api/Dash")]
    [ApiController]
    public class DashController : Controller
    {

        public RequestorModel obj1;
        public Usermodel obj3;

        public InterfaceModel obj2;

        public DashController(InterfaceModel interfaceobj)
        {

            obj2 = interfaceobj;
        }



        //Login
        [HttpGet("Login/{email}/{password}")]
        public IActionResult Login(string email, string password)
        {
            obj3 = obj2.Login(email, password);
            if (obj3 == null)
            {
                return Ok(null);
            }
            else
            {
                return Ok(obj3);
            }
        }

        //send

        [HttpPost("Send")]
        public IActionResult Send([Microsoft.AspNetCore.Mvc.FromBody] RequestorModel content)
        {
            obj1 = new RequestorModel();
            obj1 = obj2.Send(content);

            return Ok(obj1);
        }

        //requests
        [HttpGet("Requests")]
        public IActionResult Requests()
        {
            List<RequestorModel> obj5 = new List<RequestorModel>();
            obj5 = obj2.Requests();
            if (obj5 != null)
            {
                return Ok(obj5);
            }
            else
            {
                return (null);
            }
        }

        //AccountwiseNotification
        [HttpGet("AccountwiseNotification")]
        public IActionResult AccountwiseNotification()
        {
            List<CountModel> TotalNotification = new List<CountModel>();
            TotalNotification = obj2.AccountwiseNotification();
            if (TotalNotification.Count!=0)
            {
                return Ok(TotalNotification);
            }
            else
            {
                return (null);
            }

        }

        //NotificationTypeCount
        [HttpGet("NotificationTypeCount/{name}")]
        public IActionResult NotificationTypeCount(string name)
        {
            NotificationTypeCountModel NotificationType = new NotificationTypeCountModel();
            NotificationType = obj2.NotificationTypeCount(name);
            if (NotificationType!=null)
            {
                return Ok(NotificationType);
            }
            else
            {
                return NotFound();
            }

        }

        //MonthlyNotification
        //[HttpGet("MonthlyNotification")]
        //public IActionResult MonthlyNotification()
        //{
        //    List<MonthlyCount> NotificationByMonth = new List<MonthlyCount>();
        //    NotificationByMonth = obj2.MonthlyNotification();
        //    if (NotificationByMonth.Count != 0)
        //    {
        //        return Ok(NotificationByMonth);
        //    }
        //    else
        //    {
        //        return (null);
        //    }

        //}
        [HttpPost("Approve")]
        public IActionResult Approve([Microsoft.AspNetCore.Mvc.FromBody] RequestorModel content)
        {
            const string accountSid = "AC71e6f8c2c252633e266c6380ea61bd7c";
            const string authToken = "2465c59707d0a04b38182d210b881240";

            TwilioClient.Init(accountSid, authToken);

            var message = MessageResource.Create(
                body: "alo !",
                from: new Twilio.Types.PhoneNumber("+15075937045"),
                to: new Twilio.Types.PhoneNumber("+919961767824")
            );


           var call = CallResource.Create(
           url: new Uri("https://handler.twilio.com/twiml/EH130124aabaffc6581e6f45a53e1c0829"),
           to: new Twilio.Types.PhoneNumber("+919961767824"),
           from: new Twilio.Types.PhoneNumber("+15075937045")
       );
            var check = obj2.Approve(content);
            if(check==true)
            {
                return Ok();
            }
            return NotFound();
            
        }

        //Reject
        [HttpDelete("Reject/{id}")]

        public IActionResult Reject(int id)
        {
            int status = obj2.Reject(id);
            if (status == 1)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }



    }
}



