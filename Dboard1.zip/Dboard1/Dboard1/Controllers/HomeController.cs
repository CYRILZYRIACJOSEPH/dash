﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DashBoard.Models;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Net.Http.Headers;
using MahApps.Metro.Controls.Dialogs;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;

namespace DashBoard.Controllers
{
    public class HomeController : Controller
    {

        public RequestorModel obj1;
        public InterfaceModel obj2;
        private object client;

        public HomeController()
        {
            
        }
        public HttpClient api()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:44346/api/Dash/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }


           public async Task<ActionResult> Login(string email, string password)
        {
            var client = api();
            HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44346/api/Dash/Login/" + email + "/" + password);
            if (responseMessage.IsSuccessStatusCode)
            {
                Usermodel user = JsonConvert.DeserializeObject<Usermodel>(await responseMessage.Content.ReadAsStringAsync());
                if (user != null)
                {
                    var claims = new List<Claim>()
                {
                    new Claim(ClaimTypes.Name,user.email),
                    new Claim(ClaimTypes.Role,user.role)
                };
                    var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                    var princilple = new ClaimsPrincipal(identity);
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, princilple);


                    return RedirectToAction("login1", "Home");     
                }
                else
                {
                    TempData["Message"] = "Invalid Username/Password";
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                return RedirectToAction("Error", "Home");
            }

         }
        public async Task<IActionResult>ApproverAsync()
        {
            var client = api();
            HttpResponseMessage responseMessage = await client.GetAsync("https://localhost:44346/api/Dash/Requests/");
            if (responseMessage.IsSuccessStatusCode)
            {
                List<RequestorModel> user = JsonConvert.DeserializeObject<List<RequestorModel>>(await responseMessage.Content.ReadAsStringAsync());
                ViewBag.RequestorModel = user;
                return View(user);
            }
            else
            {
                return RedirectToAction("Error", "Home");
            }


        }
            public async Task<ActionResult> Send(RequestorModel content)
            {

            var client = api();
                string data = JsonConvert.SerializeObject(content);
                var stringContent = new StringContent(data, Encoding.UTF8, "application/json");
                var responseMessage = await client.PostAsync("https://localhost:44346/api/Dash/Send", stringContent);
                if (responseMessage.IsSuccessStatusCode)
                {
                    RequestorModel std;
                    std = JsonConvert.DeserializeObject<RequestorModel>(await responseMessage.Content.ReadAsStringAsync());
                    TempData["Message"] = "Success message text.";
                    return RedirectToAction("Requestor", "Home");
                }
                else
                {
                    TempData["Message"] = "Invalid Username/Password";
                    return RedirectToAction("Error", "Home");
                }

            }

        public async Task<ActionResult> Approve(RequestorModel dataobj)
        {
            string data = JsonConvert.SerializeObject(dataobj);
            var stringContent = new StringContent(JsonConvert.SerializeObject(dataobj), Encoding.UTF8, "application/json");
            var client = api();
            HttpResponseMessage responseMessage = await client.PostAsync("https://localhost:44346/api/Dash/Approve", stringContent);

            if (responseMessage.IsSuccessStatusCode)
            {
                return RedirectToAction("Approver", "Home");

            }
            else
            {
                return RedirectToAction("Error", "Home");
            }
        }



        //Reject

        public async Task<ActionResult> Reject(int id)
        {
            var client = api();
            HttpResponseMessage responseMessage = await client.DeleteAsync("https://localhost:44346/api/Dash/Reject/ " + id);

            if (responseMessage.IsSuccessStatusCode)
            {
                RequestorModel user = JsonConvert.DeserializeObject<RequestorModel>(await responseMessage.Content.ReadAsStringAsync());
               
                return RedirectToAction("Approver", "Home");

            }
            else
            {
                return RedirectToAction("Error", "Home");
            }
        }

       public IActionResult login1()
        {
            if (User.IsInRole("superadmin"))
            {
                return RedirectToAction("Dashboard", "Home");
            }
            if (User.IsInRole("admin"))
            {
                return RedirectToAction("Approver", "Home");
            }
          
                return RedirectToAction("requestor", "Home");
            
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Dashboard()
        {
            return View();
        }

        public IActionResult App()
        {
            return View();
        }
        public IActionResult Requestor()
        {
            return View();
        }

    }
}
