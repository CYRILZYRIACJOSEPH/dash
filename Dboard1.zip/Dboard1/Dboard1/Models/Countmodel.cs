﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DashBoard.Models
{
    public class Usermodel
    {

        public string account { get; set; }

        public int uid { get; set; }
        public string role { get; set; }
        public string email { get; set; }
        public string password { get; set; }
    }
    public class TotalNotificationCount
    {
        public string account { get; set; }
        public int Count { get; set; }
    }

    public class NotificationTypeCount
    {
        public string type { get; set; }
        public int count { get; set; }
    }

    public class DateCount
    {
        public DateTime Date { get; set; }
        public string  NotificationType { get; set; }
        public int Count { get; set; }
    }
}


