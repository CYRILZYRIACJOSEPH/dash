﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DashBoard.Models
{
   
    public class RequestorModel
    {
        public int id { get; set; }
        public int uid { get; set; }
        public string email { get; set; }
        public long phone { get; set; }
        public string message { get; set; }
        public string account { get; set; }
        
        public string notification { get; set; }
        public string status { get; set; }
        public DateTime date { get; set; }
    }

    public class CountModel
    {
        public string account { get; set; }
        public int count { get; set; }
    }

    public class NotificationTypeCountModel
    {
        public string account { get; set; }
        public int sms { get; set; }
        public int email { get; set; }
        public int call { get; set; }
    }

    public class MonthlyCount
    {
        public string NotificationType { get; set; }
        public int jan { get; set; }
        public int feb { get; set; }
        public int mar { get; set; }
        public int apr { get; set; }
        public int may { get; set; }
        public int jun { get; set; }
        public int jul { get; set; }
        public int aug { get; set; }
        public int sep { get; set; }
        public int oct { get; set; }
        public int nov { get; set; }
        public int dec { get; set; }

    }
}
