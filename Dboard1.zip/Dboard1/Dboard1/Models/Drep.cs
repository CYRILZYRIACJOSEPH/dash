﻿using DashBoard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dboard1.Models
{
    public class Drep : InterfaceModel
    {

        readonly List<RequestorModel> Datalist;
        //readonly List<NotificationTypeCount> NotificationTypeCountlist;
        readonly List<Usermodel> Userlist;
        ////readonly List<TotalNotificationCount> TotalNotificationCountList;
        //readonly List<DateCount> DateList;


        public Drep()
        {
            Datalist = new List<RequestorModel>()
            {

               new RequestorModel{id=1,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="IS",notification="sms",status="pending",date=new DateTime()},
               new RequestorModel{id=11,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="IS",notification="email",status="Approved",date=new DateTime()},
                new RequestorModel{id=2,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="IS",notification="call",status="Approved",date=new DateTime()},
               new RequestorModel{id=3,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="Infinity",notification="sms",status="Approved",date=new DateTime()},
               new RequestorModel{id=4,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="Infinity",notification="email",status="Approved",date=new DateTime()},
              new RequestorModel{id=1,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="Infinity",notification="call",status="Approved",date=new DateTime()},
                new RequestorModel{id=5,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="Infinity",notification="call",status="Approved",date=new DateTime()},
               new RequestorModel{id=6,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="ODC",notification="email",status="Approved",date=new DateTime()},
               new RequestorModel{id=7,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="ODC",notification="email",status="Approved",date=new DateTime()},
                new RequestorModel{id=89,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="ODC",notification="email",status="Approved",date=new DateTime()},
               new RequestorModel{id=8,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="ODC",notification="call",status="Approved",date=new DateTime()},

                 new RequestorModel{id=70,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="ODC",notification="sms",status="Approved",date=new DateTime()},new RequestorModel{id=71,uid=1,email="joseph@gmail.com",phone=786789876,message="hai all",account="ODC",notification="sms",status="Approved",date=new DateTime()},
            };


            Userlist = new List<Usermodel>()
            {
                 new Usermodel{account= "IS", uid=1,role="superadmin",email="superadmin@gmail.com",password="superadmin"},
                 new Usermodel{account= "IS", uid=2,role="admin",email="admin@gmail.com",password="admin"},
                 new Usermodel{account= "IS", uid=3,role="requestor",email="a@gmail.com",password="a"},
                 new Usermodel{account= "IS", uid=4,role="requestor",email="a@gmail.com",password="a" },
                 new Usermodel{account= "IS", uid=5,role="requestor",email="a@gmail.com",password="a"},
                 new Usermodel{account= "Infinity", uid=6,role="requestor",email="a@gmail.com",password="a" },
                 new Usermodel{account= "Infinity", uid=7,role="requestor",email="b@gmail.com",password="b"},
                 new Usermodel{account= "Infinity", uid=8,role="requestor",email="c@gmail.com",password="c" },
                 new Usermodel{account= "Infinity", uid=9,role="requestor",email="d@gmail.com",password="d"},
                 new Usermodel{account= "Infinity", uid=10,role="requestor",email="e@gmail.com",password="e" },
                 new Usermodel{account= "ODC", uid=11,role="requestor",email="f@gmail.com",password="f" },
                 new Usermodel{account= "ODC", uid=12,role="requestor" ,email="g@gmail.com",password="g"},
                 new Usermodel{account= "ODC", uid=13,role="requestor",email="h@gmail.com",password="h" },
                 new Usermodel{account= "ODC", uid=14,role="requestor",email="i@gmail.com",password="i" },
                 new Usermodel{account= "ODC", uid=15,role="requestor",email="j@gmail.com",password="j" },

            };
        }


        //login
        public Usermodel Login(string email, string password)
        {
            Usermodel stdobj = Userlist.Find(p => p.email == email && p.password == password);
            return stdobj;
        }
        public RequestorModel Send(RequestorModel dataobj)
        {

            
            int maxid = 0;
            if (Datalist.Count > 0)
            {
                maxid = Datalist.Max(p => p.id);
                maxid = maxid + 1;
            }
            else
            {
                maxid = 1;
            }
            dataobj.id = maxid;
            dataobj.status = "pending";


         
            Datalist.Add(dataobj);
            return dataobj;
        }

        public List<RequestorModel> Requests()
        {
            return Datalist.FindAll(p => p.status == "pending");
        }

        public bool Approve(RequestorModel dataobj)
        {
            DateTime today = DateTime.Now;
            var item = Datalist.Find(p => p.id == dataobj.id);
            if (item != null)
            {

                item.date = today.Date;
                item.status = "Approved";
                return true;
            }
            return false;
        }


        public int Reject(int id)
        {
            var Itemtoremove = Datalist.SingleOrDefault(r => r.id == id);
            if (Itemtoremove != null)
            {
                Datalist.Remove(Itemtoremove);
                return 1;
            }
            else
            {
                return 0;
            }
        }

       
        public List<CountModel> AccountwiseNotification()
        {
            
            List<CountModel> TotalNotification = new List<CountModel>();
            CountModel notifications = new CountModel();
            var account = Datalist.Select(p => p.account).Distinct().ToList();
            foreach(var item in account)
            {
                notifications = new CountModel();
                int count = 0;
                foreach(var data in Datalist)
                {
                    if(data.account==item && data.status=="Approved")
                    {
                        count =count+ 1;
                    }
                }
                notifications.account = item;
                notifications.count = count;
                TotalNotification.Add(notifications);

            }

            return TotalNotification;

        }


        public NotificationTypeCountModel NotificationTypeCount(string name)
        {
            List<RequestorModel> notifications = new List<RequestorModel>();
            NotificationTypeCountModel NotificationType = new NotificationTypeCountModel();
            NotificationTypeCountModel result = new NotificationTypeCountModel();
            int sms=0, call=0, email=0;
            notifications = Datalist.FindAll(p => p.account == name);
            foreach(var item in notifications)
            {
                if (item.notification == "sms" && item.status=="Approved")
                {
                    sms = sms + 1;
                }
                else if (item.notification == "call" && item.status == "Approved") 
                {
                    call = call + 1;
                }
                else if(item.notification == "email" && item.status == "Approved")
                {
                    email = email + 1;
                }
            }

                result.call = call;
                result.sms = sms;
                result.email = email;
                 
                
                return result;
            
            }
        //public List<CountModel> MonthlyNotification()
        //{

        //    List<MonthlyCount> NotificationByMonth = new List<MonthlyCount>();


        //}
    }
}
