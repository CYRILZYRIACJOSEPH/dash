﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DashBoard.Models
{
    public interface InterfaceModel
    {

        Usermodel Login(string email, string password);
        RequestorModel Send(RequestorModel std);
        //RequestorModel UpdateCount(RequestorModel std);
        bool Approve(RequestorModel std);
        List<RequestorModel>Requests();

        public int Reject(int id);
        List<CountModel> AccountwiseNotification();
        NotificationTypeCountModel NotificationTypeCount(string name);
        //List<NotificationTypeCountModel> MonthlyNotification();
    }
}
